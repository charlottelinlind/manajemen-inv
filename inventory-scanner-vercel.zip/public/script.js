
function onScanSuccess(decodedText, decodedResult) {
  document.getElementById("status").innerText = `Scanned: ${decodedText}`;
  fetch('/api/scan', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ code: decodedText })
  }).then(res => res.json())
    .then(data => console.log(data))
    .catch(err => console.error(err));
}

const html5QrcodeScanner = new Html5QrcodeScanner("reader", { fps: 10, qrbox: 250 });
html5QrcodeScanner.render(onScanSuccess);

function downloadExcel() {
  window.location.href = '/api/download';
}
