
const fs = require('fs');
const path = require('path');

module.exports = async (req, res) => {
  if (req.method !== 'POST') return res.status(405).end();

  const { code } = req.body;
  const filePath = path.resolve('./', 'inventory.json');
  const inventory = JSON.parse(fs.readFileSync(filePath));

  const item = inventory.find(i => i.code === code);
  if (item) {
    item.checked = true;
    fs.writeFileSync(filePath, JSON.stringify(inventory, null, 2));
    return res.json({ message: 'Item checked.' });
  } else {
    return res.status(404).json({ message: 'Item not found.' });
  }
};
